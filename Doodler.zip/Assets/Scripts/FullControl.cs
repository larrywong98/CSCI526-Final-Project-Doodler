﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FullControl : MonoBehaviour
{
    public static int buttonNum=0;
    public static int isTriggered=0;
    public static int dialogueRBCEnd=0;
    public static int id=0;
    public static int collectOxygen=0;
    public static int deadGreenBacteria=0;
    public static int deadboss=0;
    public static int[] canOpen=new int[100]; 
    public static int[] isOpen=new int[100];
    public static int[] enterOnce=new int[100];
    public static int glucose=0;
    public static float mainCharacterMoveSpeed=20f;
    public static int savedSpot=1;

    public static float hp;
    public static float sp;
}
