﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class utimate : MonoBehaviour
{
    // Start is called before the first frame update
    public void UtimateSkill(){
        Debug.Log("utimate");
    }
}
